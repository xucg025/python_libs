# -*- coding: utf-8 -*-
# @author: Spark
# @file: tasks.py
# @ide: PyCharm
# @time: 2020-01-07 14:05:35

import time
from celery import Celery
from celery.utils.log import get_task_logger
from celery import Task

broker = 'redis://root:ajmd123@192.168.174.28:6379/1'
backend = 'redis://root:ajmd123@192.168.174.28:6379/0'
# backend = None

app = Celery('app_name', backend=backend, broker=broker)


@app.task  # 普通函数装饰为 celery task
def add(x, y):
    return x + y


# class MyTask(Task):
#     def on_success(self, retval, task_id, args, kwargs):
#         print('task done: {0}'.format(retval))
#         return super(MyTask, self).on_success(retval, task_id, args, kwargs)
#
#     def on_failure(self, exc, task_id, args, kwargs, einfo):
#         print('task fail, reason: {0}'.format(exc))
#         return super(MyTask, self).on_failure(exc, task_id, args, kwargs, einfo)
#
#
# @app.task(base=MyTask)
# def add(x, y):
#     return x + y

# logger = get_task_logger(__name__)
#
#
# @app.task(bind=True)
# def add(self, x, y):
#     logger.info(self.request.__dict__)
#     return x + y

# @app.task(bind=True)
# def test_mes(self):
#     for i in range(1, 100):
#         time.sleep(1)
#         self.update_state(state="PROGRESS", meta={'p': i*10})
#     return 'finish'


# app.config_from_object('celery_config')
#
#
# @app.task(bind=True)
# def period_task(self):
#     i = 0
#     while True:
#         i += 1
#         time.sleep(1)
#         print(i)
#         if i >= 30:
#             break
#     print('period task done: {0}'.format(self.request.id))
