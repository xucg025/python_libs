# -*- coding: utf-8 -*-
# @author: Spark
# @file: trigger.py
# @ide: PyCharm
# @time: 2020-01-07 14:12:47

# import time
# from tasks import add
#
# result = add.delay(4, 4)  # 不要直接 add(4, 4)，这里需要用 celery 提供的接口 delay 进行调用
# while not result.ready():
#     time.sleep(1)
# print('task done: {0}'.format(result.get()))


# from tasks import test_mes
# import sys
#
#
# def pm(body):
#     res = body.get('result')
#     if body.get('status') == 'PROGRESS':
#         sys.stdout.write('\r任务进度: {0}%'.format(res.get('p')))
#         sys.stdout.flush()
#     else:
#         print('\r')
#         print(res)
#
#
# r = test_mes.delay()
# print(r.get(on_message=pm, propagate=False))

# from tasks import period_task
#
# period_task.delay()

from tasks import add

for i in range(5):
    result = add.delay(i, i+1)
    result.get(propagate=False)